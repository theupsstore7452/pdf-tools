module Da.Layout exposing (stack, row, grid, container, separator)

{-| Content layouts without document sizing, scroll locking, or app navigation.
All dimensions adapt to the available container. Override CSS tokens for spacing.

@docs stack, row, grid, container, separator

-}

import Html exposing (Html)
import Html.Attributes as A


stack : List (Html.Attribute msg) -> List (Html msg) -> Html msg
stack attrs children =
    Html.div (attrs ++ [ A.class "da-stack" ]) children


row : List (Html.Attribute msg) -> List (Html msg) -> Html msg
row attrs children =
    Html.div (attrs ++ [ A.class "da-row" ]) children


grid : List (Html.Attribute msg) -> List (Html msg) -> Html msg
grid attrs children =
    Html.div (attrs ++ [ A.class "da-grid" ]) children


container : List (Html.Attribute msg) -> List (Html msg) -> Html msg
container attrs children =
    Html.div (attrs ++ [ A.class "da-container" ]) children


separator : Html msg
separator =
    Html.hr [ A.class "da-separator" ] []
