module Da.Menu exposing (Config, Item, config, trigger, view)

{-| Anchored command menus. Requires the opt-in browser adapter for opening,
positioning, Arrow/Home/End navigation, typeahead, dismissal, and focus return.
The app handles each item's message and closes the controlled menu. Use
Da.Popover for fields and ordinary content; use Da.Dropdown for selecting values.

@docs Config, Item, config, trigger, view

-}

import Da.Internal.Overlay as Overlay
import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E


type alias Config msg =
    Overlay.Config msg


type alias Item msg =
    { id : String, label : String, disabled : Bool, onSelect : msg }


config : String -> String -> String -> msg -> Config msg
config =
    Overlay.config


trigger : List (Html.Attribute msg) -> Config msg -> String -> msg -> Html msg
trigger =
    Overlay.trigger "menu"


view : List (Html.Attribute msg) -> Config msg -> List (Item msg) -> Html msg
view attrs settings items =
    Html.div (attrs ++ Overlay.attributes "menu" settings ++ [ A.attribute "role" "menu", A.tabindex -1 ])
        (List.map
            (\item ->
                Html.button
                    ([ A.id (settings.id ++ "-item-" ++ item.id), A.type_ "button", A.class "da-menu__item", A.attribute "role" "menuitem", A.tabindex -1, A.disabled item.disabled ]
                        ++ (if item.disabled then
                                []

                            else
                                [ E.onClick item.onSelect ]
                           )
                    )
                    [ Html.text item.label ]
            )
            items
        )
