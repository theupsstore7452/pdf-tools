module Da.Combobox exposing (Option, State, Change, Control, initial, view, subscriptions, reveal)

{-| Editable search over a finite set of allowed values. The app owns query,
selected value, options, loading/error state, and an opaque State per instance.
Typing and arrow navigation never commit a value. Enter or an option click
commits; Escape, Tab, blur, and outside clicks restore the selected label.
Handle every Change, wire subscriptions, and call reveal after applying it.
No arbitrary text value or native form-data entry is submitted.

@docs Option, State, Change, Control, initial, view, subscriptions, reveal

-}

import Browser.Dom
import Browser.Events
import Da.Field as Field
import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E
import Json.Decode as D
import Task


type alias Option =
    { value : String, label : String, description : Maybe String, group : Maybe String, disabled : Bool }


type State
    = State { open : Bool, edited : Bool, active : Maybe String }


type alias Change =
    { state : State, value : String, query : String }


type alias Control msg =
    { value : String
    , query : String
    , state : State
    , options : List Option
    , loading : Bool
    , error : Maybe String
    , onChange : Change -> msg
    }


initial : State
initial =
    State { open = False, edited = False, active = Nothing }


label : Control msg -> String
label control =
    control.options |> List.filter (\option -> option.value == control.value) |> List.head |> Maybe.map .label |> Maybe.withDefault ""


matches : Control msg -> List ( Int, Option )
matches control =
    let
        (State state) =
            control.state

        query =
            String.toLower (String.trim control.query)

        filtered =
            control.options |> List.indexedMap Tuple.pair |> List.filter (\( _, option ) -> not state.edited || String.contains query (String.toLower option.label))

        groups =
            filtered
                |> List.map (Tuple.second >> .group)
                |> List.foldl
                    (\group acc ->
                        if List.member group acc then
                            acc

                        else
                            acc ++ [ group ]
                    )
                    []
    in
    List.concatMap (\group -> List.filter (\( _, option ) -> option.group == group) filtered) groups


available : Control msg -> List ( Int, Option )
available control =
    if control.loading || control.error /= Nothing then
        []

    else
        matches control |> List.filter (not << .disabled << Tuple.second)


active : Control msg -> Maybe ( Int, Option )
active control =
    let
        (State state) =
            control.state
    in
    available control |> List.filter (\( _, option ) -> Just option.value == state.active) |> List.head


close : Control msg -> Change
close control =
    { state = initial, value = control.value, query = label control }


open : Control msg -> Change
open control =
    { state = State { open = True, edited = False, active = Nothing }, value = control.value, query = label control }


choose : Option -> Control msg -> Change
choose option control =
    { state = initial, value = option.value, query = option.label }



-- Stop propagation to ask Elm's browser runtime for a synchronous render.
-- A following key or pointer event must see the state just emitted, even when
-- events arrive within the same animation frame (for example ArrowDown, Enter).


sync : String -> D.Decoder msg -> Html.Attribute msg
sync event decoder =
    E.custom event (D.map (\message -> { message = message, stopPropagation = True, preventDefault = False }) decoder)


syncPrevent : String -> D.Decoder ( msg, Bool ) -> Html.Attribute msg
syncPrevent event decoder =
    E.custom event (D.map (\( message, prevent ) -> { message = message, stopPropagation = True, preventDefault = prevent }) decoder)


edit : String -> Control msg -> Change
edit query control =
    { state = State { open = True, edited = True, active = Nothing }, value = control.value, query = query }


keyDecoder : Control msg -> D.Decoder ( msg, Bool )
keyDecoder control =
    D.map3 (\key modified composing -> ( key, modified, composing ))
        (D.field "key" D.string)
        (D.oneOf [ D.map2 (||) (D.field "ctrlKey" D.bool) (D.field "metaKey" D.bool), D.succeed False ])
        (D.oneOf [ D.field "isComposing" D.bool, D.succeed False ])
        |> D.andThen
            (\( key, modified, composing ) ->
                let
                    (State state) =
                        control.state

                    current =
                        if state.open then
                            control

                        else
                            { control | state = (open control).state }

                    options =
                        available current

                    index =
                        options |> List.indexedMap (\i ( _, option ) -> ( i, option.value )) |> List.filter (\( _, value ) -> Just value == state.active) |> List.head |> Maybe.map Tuple.first

                    at i =
                        options |> List.drop (clamp 0 (max 0 (List.length options - 1)) i) |> List.head |> Maybe.map (Tuple.second >> .value)

                    navigate direction =
                        let
                            next =
                                case index of
                                    Just i ->
                                        at (i + direction)

                                    Nothing ->
                                        if direction < 0 then
                                            List.reverse options |> List.head |> Maybe.map (Tuple.second >> .value)

                                        else
                                            at 0

                            (State currentState) =
                                current.state
                        in
                        D.succeed
                            ( control.onChange
                                { state = State { currentState | open = True, active = next }
                                , value = control.value
                                , query =
                                    if state.open then
                                        control.query

                                    else
                                        label control
                                }
                            , True
                            )
                in
                if composing || modified then
                    D.fail "Native text editing"

                else
                    case key of
                        "ArrowDown" ->
                            navigate 1

                        "ArrowUp" ->
                            navigate -1

                        "Enter" ->
                            if state.open then
                                D.succeed ( control.onChange (active control |> Maybe.map (\( _, option ) -> choose option control) |> Maybe.withDefault (close control)), True )

                            else
                                D.fail "Native form submission"

                        "Escape" ->
                            if state.open then
                                D.succeed ( control.onChange (close control), True )

                            else
                                D.fail "Closed combobox"

                        "Tab" ->
                            if state.open then
                                D.succeed ( control.onChange (close control), False )

                            else
                                D.fail "Native Tab"

                        _ ->
                            D.fail "Native text editing"
            )


ancestor : String -> D.Decoder Bool
ancestor id =
    D.oneOf
        [ D.field "id" D.string
            |> D.andThen
                (\found ->
                    if found == id then
                        D.succeed True

                    else
                        D.field "parentElement" (D.lazy (\_ -> ancestor id))
                )
        , D.succeed False
        ]


subscriptions : Field.Config -> Control msg -> Sub msg
subscriptions settings control =
    let
        (State state) =
            control.state
    in
    if state.open && not settings.disabled then
        Browser.Events.onClick
            (D.field "target" (ancestor (settings.id ++ "-combobox"))
                |> D.andThen
                    (\inside ->
                        if inside then
                            D.fail "Inside combobox"

                        else
                            D.succeed (control.onChange (close control))
                    )
            )

    else
        Sub.none


optionId : String -> Int -> String
optionId id index =
    id ++ "-option-" ++ String.fromInt index


reveal : String -> Control msg -> (Result Browser.Dom.Error () -> msg) -> Cmd msg
reveal id control onResult =
    let
        (State state) =
            control.state

        listId =
            id ++ "-listbox"
    in
    case ( state.open, active control ) of
        ( True, Just ( index, _ ) ) ->
            Task.map3 (\list option viewport -> ( list, option, viewport ))
                (Browser.Dom.getElement listId)
                (Browser.Dom.getElement (optionId id index))
                (Browser.Dom.getViewportOf listId)
                |> Task.andThen
                    (\( list, option, viewport ) ->
                        let
                            top =
                                option.element.y - list.element.y

                            delta =
                                if top < 0 then
                                    top

                                else
                                    max 0 (top + option.element.height - viewport.viewport.height)
                        in
                        Browser.Dom.setViewportOf listId viewport.viewport.x (viewport.viewport.y + delta)
                    )
                |> Task.andThen (\_ -> Task.map2 Tuple.pair (Browser.Dom.getElement (optionId id index)) Browser.Dom.getViewport)
                |> Task.andThen
                    (\( option, viewport ) ->
                        if option.element.y < viewport.viewport.y then
                            Browser.Dom.setViewport viewport.viewport.x (max 0 (option.element.y - 8))

                        else if option.element.y + option.element.height > viewport.viewport.y + viewport.viewport.height then
                            Browser.Dom.setViewport viewport.viewport.x (option.element.y + option.element.height - viewport.viewport.height + 8)

                        else
                            Task.succeed ()
                    )
                |> Task.attempt onResult

        _ ->
            Cmd.none


view : List (Html.Attribute msg) -> Field.Config -> Control msg -> Html msg
view attrs settings control =
    let
        (State state) =
            control.state

        expanded =
            state.open && not settings.disabled

        helpId =
            settings.id ++ "-help"

        errorId =
            settings.id ++ "-error"

        described =
            [ if settings.description /= Nothing then
                Just helpId

              else
                Nothing
            , if settings.error /= Nothing then
                Just errorId

              else
                Nothing
            ]
                |> List.filterMap identity
                |> String.join " "

        selectedActive =
            active control |> Maybe.map Tuple.first

        shown =
            if control.loading || control.error /= Nothing then
                []

            else
                matches control

        groups =
            shown
                |> List.map (Tuple.second >> .group)
                |> List.foldl
                    (\group acc ->
                        if List.member group acc then
                            acc

                        else
                            acc ++ [ group ]
                    )
                    []

        status =
            if control.loading then
                "Loading options…"

            else
                Maybe.withDefault
                    (if List.isEmpty shown then
                        "No matching options"

                     else if List.isEmpty (available control) then
                        "No available options"

                     else
                        ""
                    )
                    control.error

        renderOption ( index, option ) =
            Html.div
                ([ A.id (optionId settings.id index)
                 , A.class "da-combobox__option"
                 , A.attribute "role" "option"
                 , A.attribute "aria-selected"
                    (if selectedActive == Just index then
                        "true"

                     else
                        "false"
                    )
                 , A.attribute "aria-disabled"
                    (if option.disabled || control.loading || control.error /= Nothing then
                        "true"

                     else
                        "false"
                    )
                 , A.attribute "data-da-selected"
                    (if option.value == control.value then
                        "true"

                     else
                        "false"
                    )
                 ]
                    ++ (if option.disabled || control.loading || control.error /= Nothing || settings.disabled then
                            []

                        else
                            [ syncPrevent "pointerdown" (D.succeed ( control.onChange { state = control.state, value = control.value, query = control.query }, True ))
                            , syncPrevent "mousedown" (D.succeed ( control.onChange { state = control.state, value = control.value, query = control.query }, True ))
                            , sync "click" (D.succeed (control.onChange (choose option control)))
                            ]
                       )
                    ++ (if option.description /= Nothing then
                            [ A.attribute "aria-describedby" (optionId settings.id index ++ "-description") ]

                        else
                            []
                       )
                )
                [ Html.div [ A.class "da-combobox__option-label" ]
                    [ Html.span [] [ Html.text option.label ]
                    , Html.span [ A.attribute "aria-hidden" "true" ]
                        [ Html.text
                            (if option.value == control.value then
                                "✓"

                             else
                                ""
                            )
                        ]
                    ]
                , option.description |> Maybe.map (\description -> Html.p [ A.id (optionId settings.id index ++ "-description"), A.class "da-combobox__description" ] [ Html.text description ]) |> Maybe.withDefault (Html.text "")
                ]
    in
    Html.div [ A.id (settings.id ++ "-combobox"), A.class "da-field da-field--surface da-combobox" ]
        [ Html.label [ A.for settings.id, A.class "da-field__label" ]
            [ Html.text
                (settings.label
                    ++ (if settings.required then
                            " (required)"

                        else
                            ""
                       )
                )
            ]
        , Html.input
            (attrs
                ++ [ A.id settings.id
                   , A.class "da-input"
                   , A.type_ "text"
                   , A.value
                        (if expanded then
                            control.query

                         else
                            label control
                        )
                   , A.disabled settings.disabled
                   , A.autocomplete False
                   , A.attribute "role" "combobox"
                   , A.attribute "aria-autocomplete" "list"
                   , A.attribute "aria-haspopup" "listbox"
                   , A.attribute "aria-controls" (settings.id ++ "-listbox")
                   , A.attribute "aria-expanded"
                        (if expanded then
                            "true"

                         else
                            "false"
                        )
                   , A.attribute "aria-required"
                        (if settings.required then
                            "true"

                         else
                            "false"
                        )
                   , A.attribute "aria-invalid"
                        (if settings.error /= Nothing then
                            "true"

                         else
                            "false"
                        )
                   ]
                ++ (if described /= "" then
                        [ A.attribute "aria-describedby" described ]

                    else
                        []
                   )
                ++ (if expanded then
                        selectedActive |> Maybe.map (\index -> [ A.attribute "aria-activedescendant" (optionId settings.id index) ]) |> Maybe.withDefault []

                    else
                        []
                   )
                ++ (if settings.disabled then
                        []

                    else
                        [ sync "focus" (D.succeed (control.onChange (open control)))
                        , sync "blur" (D.succeed (control.onChange (close control)))
                        , sync "input" (D.at [ "target", "value" ] D.string |> D.map (\query -> control.onChange (edit query control)))
                        , syncPrevent "keydown" (keyDecoder control)
                        ]
                   )
            )
            []
        , Html.div [ A.class "da-combobox__popup", A.hidden (not expanded) ]
            [ Html.div
                [ A.id (settings.id ++ "-listbox")
                , A.class "da-combobox__list"
                , A.attribute "role" "listbox"
                , A.attribute "aria-label" settings.label
                , A.attribute "aria-busy"
                    (if control.loading then
                        "true"

                     else
                        "false"
                    )
                ]
                (List.indexedMap
                    (\index group ->
                        let
                            rows =
                                shown |> List.filter (\( _, option ) -> option.group == group) |> List.map renderOption

                            groupId =
                                settings.id ++ "-group-" ++ String.fromInt index
                        in
                        case group of
                            Nothing ->
                                Html.div [ A.attribute "role" "presentation" ] rows

                            Just groupLabel ->
                                Html.div [ A.attribute "role" "group", A.attribute "aria-labelledby" groupId ] (Html.div [ A.id groupId, A.class "da-combobox__group", A.attribute "role" "presentation" ] [ Html.text groupLabel ] :: rows)
                    )
                    groups
                )
            , if status == "" then
                Html.text ""

              else
                Html.p [ A.class "da-combobox__status", A.attribute "role" "status" ] [ Html.text status ]
            ]
        , settings.description |> Maybe.map (\help -> Html.p [ A.id helpId, A.class "da-field__help" ] [ Html.text help ]) |> Maybe.withDefault (Html.text "")
        , settings.error |> Maybe.map (\error -> Html.p [ A.id errorId, A.class "da-field__error" ] [ Html.text error ]) |> Maybe.withDefault (Html.text "")
        ]
