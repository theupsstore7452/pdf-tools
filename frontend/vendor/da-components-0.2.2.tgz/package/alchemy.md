# da-components Invariants

This document records the durable rules that library changes must preserve.

## INV-SHARED-FOUNDATION: Reuse across applications

- **Scope:** Public components, themes, and composition helpers.
- **Rule:** Serve as the main component library for existing and future Elm HTML/CSS web apps, providing a consistent UI foundation. Public components must not depend on PDF Tools, Squire, or other consumer models, APIs, workflow messages, processing, or storage policy. Support both ordinary forms and compact workspace controls through shared presentations; consuming apps own their workspace composition.
- **Owner:** The public `Da.*` modules and shared stylesheet.
- **Evidence:** Compile the standalone catalog and a clean consumer using the distributed source bundle without PDF Tools code.
- **Origin:** The user wants reusable components with consistent style and an easier development experience across apps, and confirmed Elm HTML/CSS as the rendering approach. On October 12, 2026 the user identified Squire's crowded integration and reaffirmed DA as the main component library for all their web apps.

## INV-FOCUSED-CORE: Establish a small general-use core

- **Scope:** Initial scope and future additions.
- **Rule:** Start with a solid restrained core for common app needs, including buttons, cards, and forms. New components must serve a concrete reusable need and have documented interaction contracts rather than being added solely to match a large catalog.
- **Owner:** The public module catalog and component documentation.
- **Evidence:** Review additions against repeated tasks, meaningful states, API ownership, and verification coverage.
- **Origin:** The user explicitly requested a general-use foundation that is not too much.

## INV-STANDARD-STRUCTURE: Preserve familiar component anatomy and interaction

- **Scope:** Layout, labels, grouping, controls, navigation, and feedback.
- **Rule:** Use conventional component structure and accessible standard interactions. Treat shadcn as a structural and behavior reference without adopting its visual styling. Preserve keyboard access, visible focus, programmatic labels, recoverable input drafts, and containment at supported viewport sizes.
- **Owner:** Elm markup and interaction helpers, CSS layouts, and catalog examples.
- **Evidence:** Elm tests and browser checks for labels, native form behavior, tab focus, drafts, multiple instances, responsive reflow, and themes.
- **Origin:** The user requested standardized layout guidance for good user experience and explicitly excluded the reference's visual styling.

## INV-APP-OWNERSHIP: Keep business decisions in the consuming app

- **Scope:** Controlled values, validation, requests, and effects.
- **Rule:** Components accept displayed values and caller-owned messages. They do not own domain validation, network requests, authorization, routes, or persistence. Numeric editing retains raw drafts. CSS affects the opted-in theme scope and does not impose document sizing or scroll policy.
- **Owner:** Public component APIs and stylesheet selectors.
- **Evidence:** Component API review and standalone consumer/browser checks of drafts and style scope.
- **Origin:** Established library contract documented in README.md and implemented by the source modules.

## INV-SELECTION-PANELS: Separate value selection from tab panels

- **Scope:** Da.Tabs, Da.Field.segmented, component examples, and future selection APIs.
- **Rule:** Tabs associate selection with content panels and own their visibility. Segmented fields select a single value with native radio semantics; they must not accept panel content, generate panel relationships, or manage panel visibility. Reuse radio-field behavior for segmented presentation. Choose the component by its task and semantics, not its shape.
- **Owner:** Da.Tabs and Da.Field; the catalog and public documentation explain the boundary.
- **Evidence:** Elm and browser checks for native radio values/messages, labeling, keyboard selection, independent groups, and the absence of tab/panel roles in segmented fields. Existing tab checks continue to verify linked, mounted panels and focus.
- **Origin:** The user explicitly required that segmented controls and tabs have separate functionality and approved the distinction before authorizing implementation.

## INV-OVERLAY-LIFECYCLE: Scope optional browser effects to controlled overlays

- **Scope:** Da.Dialog, Da.Popover, Da.Menu, and the opt-in browser adapter.
- **Rule:** The consuming app owns whether each surface is open and handles dismissal requests. Only overlay consumers require the adapter; other components retain Elm/CSS-only operation. The adapter owns native opening/closing, placement, and focus lifecycle without app ports, persistence, requests, or domain policy. Installations must respect ownership across sibling and nested roots, release removed elements and listeners, and expose disposal. Dialogs use native modality; popovers contain ordinary content, and command menus own their documented keyboard interactions. Dismissal must preserve a sensible focus destination and must not steal focus from an outside click.
- **Owner:** The overlay modules, Da.Internal.Overlay, and browser/da-components.js.
- **Evidence:** Browser checks for native modal state, validation/drafts, initial focus, nondismissible pending states, Escape and Tab, outside-click focus, command navigation, positioning, multiple instances, root ownership, removal, and adapter disposal.
- **Origin:** The user authorized the recommended dialogs, popovers, menus, and their necessary browser-integration contract after reviewing the library's existing adapter-free core.

## INV-FILE-CONTROLS: Keep file policy and ordered data with the app

- **Scope:** Da.FilePicker, Da.Reorderable, and Da.FileList.
- **Rule:** File controls emit caller-owned files and interaction state without reading, uploading, validating domain content, or persisting files. Native accept/multiple chooser hints do not replace app validation of dropped files. Ordered lists emit stable item-ID orders; drag cleanup must not overwrite a committed order or its announcement. Visible move actions and keyboard moves must support reordering without dragging.
- **Owner:** Da.FilePicker, Da.Reorderable, Da.FileList, and consuming applications.
- **Evidence:** Elm checks and browser checks for chooser/drop events, nested drag hover, unsupported-file recovery in the example app, disabled controls, repeated file selection, stable identity/focus, move actions, native dragging, and drag-end ordering.
- **Origin:** The user approved the file picker/drop area and reusable ordered-list additions with file validation, uploading, and processing retained in the consuming app.

## INV-VISUAL-STYLE: Keep components minimal and coherent

- **Scope:** Shared components and the standalone catalog.
- **Rule:** Follow Uniswap as a visual reference for restrained neutral surfaces, sparse accent colors, and comfortably sized readable typography. Use a shared rounded rectangular shape system for controls, including switches, with larger corners for containers. Text fields, textareas, and selects group their label, value, and help in a rounded neutral panel, with larger numeric values and subtle outlines instead of a bottom-border treatment. Styled dropdowns must theme both their trigger and open option list consistently with the rest of the components, including selection, focus, and disabled states. Primary buttons use a solid accent fill and shade changes for interaction feedback, without an underline effect. Secondary buttons use neutral filled surfaces and neutral hover feedback. Preserve functional state cues, accessible focus, and native interactions where native controls are used.
- **Owner:** Shared component CSS and the catalog examples.
- **Evidence:** Render components in both themes, check shapes, contrast, keyboard interaction, narrow viewports, text scaling, RTL, and reduced motion with the browser suite.
- **Origin:** The user identified inconsistent switch and control shapes, supplied https://app.uniswap.org/ as the style guide, and clarified that this request applies to da-components rather than PDF Tools. The user then supplied rounded solid pink primary and neutral filled secondary button examples as the preferred style and rejected the primary button underline effect. The user supplied a Sell/Buy input reference to replace the existing input style with rounded panels, inset labels, and prominent values. The user subsequently required the Plan dropdown to match the other components and requested a dropdown component for this purpose.

## INV-OPINIONATED-MOTION: Own restrained motion defaults

- **Scope:** Shared component styling, interaction feedback, and the catalog.
- **Rule:** The library owns a coherent, minimal motion system with built-in behavior and fixed timings and easing. Do not add animation options, opt-in attributes, or public motion tokens. Honor reduced-motion preferences automatically. Focus, input, accessibility state, validation indicators, and native open/hidden behavior must not wait for animation. Preserve disabled and busy behavior, RTL travel, and mounted tab drafts. Structural containers stay still; motion communicates interaction and content changes. Feedback has smooth notice entrances and progress changes, with repeatable catalog demonstrations. Updating a mounted notice does not replay its entrance. Styled progress preserves native accessible semantics and immediate clamped values, uses native visuals in forced colors, and retargets smoothly when values change during motion.
- **Owner:** Shared component CSS and the public component interaction contracts; README.md documents the motion behavior.
- **Evidence:** Browser checks of press/release, rapid switch and tab interactions, disclosure reopening, feedback insertion versus text updates, progress interpolation and interruption, upload replay, native progress semantics and forced colors, keyboard focus, reduced motion, RTL, disabled and busy controls, and CSS scope; standalone catalog and consumer builds.
- **Origin:** The user requested minimal but stylish animations, clarified that this should be an opinionated UI component library without added options, and approved the built-in motion plan. The user subsequently required extremely smooth, elegant feedback animations and examples that display them to viewers.

## INV-ACCENT-CUSTOMIZATION: Let consuming apps choose the accent

- **Scope:** Public theme configuration and accent styling.
- **Rule:** Provide a documented single-color accent helper that chooses readable foreground text and scopes its overrides to the themed root. Derive shared accent tints and focus styling from that root's color; preserve per-root isolation and caller ownership of selection and persistence. Retain direct CSS-token overrides for consumers needing explicit colors.
- **Owner:** Da.Theme, shared CSS tokens, and the catalog Theme example.
- **Evidence:** Elm checks of valid and invalid color input; browser checks of custom colors in light/dark/system modes, computed contrast, nested and sibling scope isolation, and independent explicit overrides; clean consumer build using the source bundle.
- **Origin:** The user requested that users be able to easily specify the accent color when applying the component style changes.

## INV-DEVELOPMENT-COMMANDS: Keep preview startup simple

- **Scope:** Repository development commands and Nix shell.
- **Rule:** Use `just dev` as the primary preview command. It must prepare missing npm dependencies, build the current catalog, launch the local preview, and rebuild and refresh it after Elm, CSS, or catalog HTML changes. A failed rebuild must retain the last successful preview and visibly report that it is stale. Support `nix-shell --run 'just dev'` and `nix develop` with the same pinned tools. The default Nix shell provides only the tools needed for this workflow; retain npm manifests and the lockfile as the owner of Elm tool versions. Shell activation must not install dependencies or start the preview automatically.
- **Owner:** justfile, scripts/serve.mjs, shell.nix, flake.nix, flake.lock, nix/dev-shell.nix, and npm scripts.
- **Evidence:** Evaluate both pinned development-shell entry points, run `just dev` from a prepared and a clean checkout, and verify that the catalog serves at its documented local address. `npm run test:dev` checks fresh builds, CSS/Elm update events, failure retention, and recovery in a disposable fixture; Python Playwright checks the rendered preview.
- **Origin:** The user requested Just commands with `just dev` as the main preview command and a Nix shell containing only what is needed, then used `nix-shell --run 'just dev'` to launch it. The user subsequently required the command to serve the most up-to-date visual representation of the component library.

## INV-CHANGE-PREVIEW: Provide a preview after library changes

- **Scope:** Agent work that changes this component library or its catalog.
- **Rule:** After every change task, start or reuse a dev server serving the current component catalog, leave it available for the user to preview all changes, and provide its URL. Verify that the preview reflects the current sources. If the execution environment prevents starting or verifying the server, report the concrete blocker instead of claiming that a preview is running.
- **Owner:** The agent's change workflow and the repository's `just dev` command.
- **Evidence:** Check the running preview against the current build and include its reachable URL in the handoff; use Python Playwright screenshots for visual review when browser execution is available.
- **Origin:** The user explicitly requested that every future component-library change include a served dev preview of all changes.
