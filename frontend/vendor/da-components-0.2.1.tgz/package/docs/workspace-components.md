# Workspace component contracts

The standalone catalog demonstrates all additions with realistic labels and
interactive states. All public views return `Html msg`. Apps retain their models,
values, drafts, validation, requests, routing, persistence, and domain policy.

## Form and workspace presentations

Form panels remain the default. Apply `Layout.compact` to an existing themed
root, sidebar, or toolbar to use 36px controls with 14px text and reduced button
padding in that region. This is an inherited density attribute, not a layout or
scroll container. It does not shrink form panel values or hide their labels.

`Field.present presentation attrs field` wraps exactly one `Field.input`,
`textarea`, `select`, `Dropdown.view`, or `Combobox.view`. Existing configurations
and controlled values are unchanged. Presentations do not nest:

| Presentation | Use | Label |
| --- | --- | --- |
| `Field.Compact` | Sidebar or toolbar search in a small neutral panel | Visually hidden, still linked |
| `Field.Inline` | Labeled toolbar choices such as reasoning or sort order | Visible beside the value |
| `Field.Embedded` | Textarea inside an app-owned composer or other surface | Visually hidden, still linked |

Hidden labels need visible context, such as a descriptive placeholder. Help and
validation errors remain visible and linked. Keyboard focus, disabled states,
native values and draft messages retain the existing field contract. Embedded
textareas start at two lines; the consuming app owns any maximum height and
scrolling. Dropdowns and comboboxes keep their own popup behavior and adapters.

```elm
Field.present Field.Compact []
    (Field.input [ Html.Attributes.placeholder "Search projects…" ]
        (Field.config "projects-search" "Search projects")
        { value = model.query, onInput = SearchChanged, kind = Field.Search })
```

Shared buttons style pressed, selected, and current-page states from
`aria-pressed`, `aria-selected`, and `aria-current="page"`. Consumers supply the
correct semantics for the action; appearance alone does not turn a button into
a tab or radio. Use quiet buttons for navigation rows, and reserve solid primary
buttons for the primary action. Flex parents may allocate or truncate row content;
buttons can shrink without forcing a sidebar wider. The catalog's compact
workspace demonstrates realistic navigation, long labels, draft preservation,
native inline selection, and submission alongside the ordinary form examples.

## Segmented values and tabs

`Field.segmented` has the same signature as `Field.radioGroup`: attribute list,
`Field.Config`, and `{ value, onSelect, options }`. Its options are native radio
inputs with linked labels, help, validation, required state, and disabled state.
It supplies a compact presentation of the existing radio behavior.

```elm
Field.segmented [] (Field.config "fitting" "Artwork fitting")
    { value = model.fitting
    , onSelect = FittingChanged
    , options =
        [ { value = "fit", label = "Fit", disabled = False }
        , { value = "fill", label = "Fill", disabled = False }
        , { value = "stretch", label = "Stretch", disabled = False }
        ]
    }
```

Segmented fields select values and expose no panel API. `Da.Tabs` continues to
associate each tab with a mounted panel and control which panel is visible.
Changing a selected value may update a preview through the app's update function;
that does not make the field a tab system. Native radios provide Tab, arrow, and
Space interactions without a custom focus command or browser adapter.

## Buttons, action groups, badges, and activity

- `Button.content attrs appearance children message` accepts decorative graphics
  and visible text. Do not place interactive children inside a button.
- `Button.icon attrs appearance accessibleLabel graphic message` requires a
  label and hides the supplied graphic from the accessible name.
- `Button.submitContent attrs appearance children` and
  `Button.linkContent attrs variant href children` preserve native submission
  and navigation. Existing text-button APIs remain available.
- `Toolbar.view attrs label children` and `Toolbar.group` wrap labeled groups.
  They use `role="group"` and ordinary Tab order, allowing native radio and
  range fields without imposing the ARIA composite-toolbar keyboard model.
- `Badge.view attrs Feedback.Tone label` is a static state/count label. Always
  name the state in text. Badges do not announce updates on their own.
- `Activity.view attrs label` is a polite status with a decorative spinner.
  `Activity.indicator` omits the live-region role for use inside an existing
  status region. Reduced motion leaves the indicator still.

## Native overlays and the optional adapter

Copy `browser/da-components.js` from the installed source bundle into your web
assets beside the CSS. It is an ES module intended for browsers with native
`HTMLDialogElement.showModal`, Popover API, ResizeObserver, and AbortController
support. There is no polyfill or global auto-installation.

```js
import { install } from './da-components.js';

// Run after Elm has mounted the owning themed root.
const dispose = install(document.getElementById('my-app'));
// Call dispose() before permanently unmounting this root.
```

Repeated installation on the same root returns its existing disposer. Sibling
roots are independent. For nested installations, the closest installed root owns
its overlays. An installation on an ancestor can handle nested themed content
when no separate installation owns it. Use document-unique IDs everywhere.

Keep the surfaces mounted, render their controlled `open` values, and handle
`onClose` by setting the appropriate value to `False`. The adapter observes only
its owning DOM tree and emits `da-close` requests; it does not change app data or
invoke app ports. It removes native listeners and resize observers from removed
elements and closes surfaces on disposal. Optional `da-overlay-error` handlers
can be supplied in the attributes to report missing anchors or opening failures.

`Dialog.config id title onClose` starts closed, with dismissal enabled and an
English close-button label. Override `open`, `closeLabel`, `dismissible`, and
`initialFocus : Maybe String` in your app. `Dialog.view attrs config
{ body, actions }` renders a native dialog with a linked title, body, and actions.
The adapter calls `showModal`, preserving browser modality and inert background
behavior. Initial focus goes to your specified element or the title. Escape
requests dismissal; closing returns focus to the opener when it remains valid.
Backdrop clicks do not dismiss a dialog. `dismissible=False` suppresses user
dismissal while your app completes a pending operation; keep app-side guards too.

```elm
base =
    Dialog.config "preset-editor" "Edit preset" ClosePresetEditor

settings =
    { base
        | open = model.presetEditorOpen
        , initialFocus = Just "preset-name"
        , dismissible = not model.saving
    }

Dialog.view [] settings
    { body = [ presetNameField model ]
    , actions = [ Button.view [] Button.primary "Save preset" SavePreset ]
    }
```

`Popover.config id label anchorId onClose` and `Menu.config` start closed.
Their `trigger attrs config label onToggle` helpers render ordinary action
buttons with scoped IDs and expansion relationships. Popover accepts ordinary
children. Menu accepts `{ id, label, disabled, onSelect }` commands. Handle each
command in the app and close the menu in the same update. To use a context menu,
set its anchor ID to the document-unique ID of the acted-on element and open it
from that element's context-menu or keyboard handler; positioning is anchored to
that element, not arbitrary pointer coordinates.

Popovers and menus use the native top layer, align with their anchors, flip when
space is limited, and constrain their height and width to the visible viewport.
Escape returns focus to the opener. Outside clicks and focus leaving the surface
request closure while preserving the new focus destination. Menus add
ArrowUp/Down, Home/End, typeahead, disabled-command skipping, and Tab exit. A menu
trigger opens on ArrowDown/Up and enters the first/last available command.
Popovers retain normal field keyboard interactions and never trap focus.

These styles impose no document scroll lock. Apps own outer scroll policy.
Only Dialog, Popover, and Menu require the adapter.

## Searchable selection

`Combobox.view attrs fieldConfig control` uses the same field-label, help,
validation, required, and disabled conventions as the existing dropdown.
Each instance owns one `Combobox.initial` state in the app. `Control` contains:

- `value`, the committed option value; `query`, the editable search draft;
- `state`, the per-instance opaque interaction state;
- `options`, records of `{ value, label, description, group, disabled }`;
- `loading`, `error : Maybe String`, and `onChange : Change -> msg`.

Option values must be unique. Groups retain first-occurrence order; options
within each group retain their input order. Initialize query with the chosen
label. Handle every change by applying `value`, `query`, and `state`, then call
`Combobox.reveal id nextControl onResult`. Wire `Combobox.subscriptions` for each
instance using its same field configuration. Supply an app-specific retry action
outside the popup when loading fails. Reset state when resetting the form or
replacing the option collection, and reconcile removed selected values in the app.

Focusing shows available choices. Typing filters labels without committing a
value; arrow keys highlight enabled results while DOM focus stays on the input.
Enter or an option click commits the highlighted option. Escape, Tab, blur, and
outside clicks cancel search and restore the committed label. Home, End, cursor
keys, modified editing keys, and IME composition retain native input behavior.
Loading and error states make options unavailable. Empty searches have a visible
status. The component submits no native form-data entry; submit the app's value.

`Dropdown` remains the select-only component with typeahead over its full option
list. Use Combobox when the user needs an editable search field.

## Actionable feedback, ranges, and meters

`Feedback.noticeWithActions` and `Feedback.statusWithActions` take
`{ title, message, actions : List (Html msg) }`. Existing notice/status APIs keep
their signatures. `Feedback.Warning` adds a persistent caution tone; it is not an
assertive alert. Apps that exhaustively match `Feedback.Tone` must add this case.
Apps own retry/cancel actions and notification timing.

`Field.range attrs config { value, minimum, maximum, step, valueText, onInput }`
is a native bounded slider. Supply finite bounds with maximum greater than
minimum and positive step. `valueText` contains units; `onInput` receives a Float.
Parsing, meaningful precision, and domain validation remain with the app.

`Feedback.meter attrs { label, value, minimum, maximum, valueText }` is a native
measurement meter with a themed visual. It clamps values to supplied finite
bounds; supply maximum greater than minimum. `valueText` describes meaningful
units such as "62 of 100 credits". A meter measures usage or capacity. Continue
using `Feedback.progress` for completion of a task. Both retain native visuals
in forced colors, and the shared motion defaults honor reduced motion.

## File selection and ordered items

`FilePicker.view attrs Field.Config control` takes `{ state, accept, multiple,
onChange }`; initialize state with `FilePicker.initial`. Native file selection
and drops emit `Change { state, files : Maybe (List File.File) }`. Always apply
state. `Nothing` is only drag hover/cleanup; `Just files` is a new selection.
Store selected files in your model if needed. The component does not read,
upload, validate domain content, or persist files. Native chooser hints are not
validation: check dropped types, counts, and sizes in the app. Disabled pickers
suppress file-drop navigation and never emit a new file selection.

The component requires `elm/file` 1.0.5; Elm resolves its `elm/bytes` dependency.
The catalog's extension validation is a demonstration, not a content-security
check. It stores only filenames and never transmits files.

`Reorderable.view attrs { id, label, moveUp, moveDown } control` takes
`{ items, state, disabled, onChange }`. Each item is `{ id, label, content }`;
IDs must be stable and unique within a group. Initialize with
`Reorderable.initial`. Labels for move controls come from the app.

```elm
OrderChanged change ->
    let
        result =
            Reorderable.apply change model.orderState

        nextItems =
            result.order
                |> Maybe.map (itemsInIdOrder model.items)
                |> Maybe.withDefault model.items
    in
    ( { model | items = nextItems, orderState = result.state }
    , Reorderable.focus "files" change (\_ -> NoOp)
    )
```

`itemsInIdOrder` is app code that maps IDs to current records. `apply` merges drag
cleanup with the latest state and returns `order=Nothing` for interaction-only
events, preventing drag-end from reverting a just-committed order. Move buttons,
Alt+ArrowUp/Down on focused rows, and native pointer dragging are supported.
Call `focus` after applying changes; it restores the moved row, and is a no-op
for drag-only changes. A polite live region announces the item and its new
position. Touch users can use the visible move buttons. Removal belongs to the
app and can be composed inside each item's content.

## Verification

Elm tests cover public messages, semantic relationships, selection/cancellation,
disabled states, and stable ordering. Browser tests exercise native modality,
focus, menus, editable search, real FileList/drop events, drag ordering, recovery,
themes, narrow viewports, RTL, text scaling, reduced motion, and forced colors.
The dev-server check includes adapter asset serving and refresh after JS changes.
The clean consumer compiles all public modules from the packed source bundle and
verifies that the browser adapter is included. These checks do not establish
full assistive-technology conformance.
