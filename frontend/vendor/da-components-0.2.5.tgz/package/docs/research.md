# Component scope and structural research

The target is a consistent reusable foundation for existing and future Elm HTML/CSS
apps. The first release should cover general controls, containers, forms, and a few
common interactions without importing an application framework.

## Reference findings

- [shadcn component index](https://ui.shadcn.com/docs/components): a broad component
  vocabulary is useful as an expansion map, but implementing the whole catalog
  would exceed the requested initial core.
- [Button](https://ui.shadcn.com/docs/components/button): actions have consistent
  variants and native button behavior. The Elm API distinguishes actions, submit,
  and navigation rather than copying React polymorphism.
- [Card](https://ui.shadcn.com/docs/components/card): header/title/description/body/
  footer composition generalizes to settings, records, and tasks. The library
  adopts these parts, with app-selected semantic heading levels.
- [Field](https://ui.shadcn.com/docs/components/field): labeled controls, help,
  errors, semantic groups, and responsive orientation form a reusable structure.
  These become `Da.Field` and `Da.Form`; application validation is kept separate.
- [Native Select](https://ui.shadcn.com/docs/components/native-select): standard
  selection can use a native control. A custom select/combobox entails additional
  interaction contracts and is deferred.
- [WAI form grouping](https://www.w3.org/WAI/tutorials/forms/grouping/): related
  controls use fieldset and legend; checkbox/radio labels remain explicit.
- [WAI form notifications](https://www.w3.org/WAI/tutorials/forms/notifications/):
  errors need clear descriptions and associations, with a path back to fields.
- [WAI tabs pattern](https://www.w3.org/WAI/ARIA/apg/patterns/tabs/): selection,
  relationships, keyboard navigation, and focus must work together. The core uses
  immediate local panels, roving tabindex, and an explicit Elm focus command.
- [Elm application structure](https://guide.elm-lang.org/webapps/structure.html):
  reusable views do not need an individual Model/update framework. Apps retain
  state and pass values and messages into functions.
- [Elm ports](https://guide.elm-lang.org/interop/ports.html): ports are application
  facilities, unavailable in Elm registry packages. Public components require no
  app ports. Native overlays use a separately installed browser adapter with
  controlled markup and DOM dismissal events; other components need no adapter.

These are behavioral and structural references. No shadcn styling, source code,
Tailwind dependency, React dependency, icon system, or generated registry is used.

## Visual reference

[Uniswap](https://app.uniswap.org/) supplies the requested visual direction:
minimal neutral surfaces, limited accent color, comfortably sized type, and soft
rectangular controls. The shared radius connects buttons, fields, and switch
tracks; the switch thumb uses a smaller proportional radius. Circles remain on
native radio controls where their shape communicates a standard interaction.
Containers use a larger radius without adding a separate visual system.

Brand accents remain app-owned. `Theme.accent` accepts one hex color and chooses
the higher-contrast black or white foreground using sRGB relative luminance.
CSS derives a soft fill and a focus color that blends the brand toward the theme's
text color. Browser checks measure actual resolved colors, including bright and
dark accent extremes, hover, theme switching, and scope boundaries.

## Scope decision

Twenty public modules now support the common controls plus concrete workspace
needs observed in PDF Tools and Squire: content/icon buttons, segmented values,
bounded sliders, compact labels/activity, action groups, controlled native
overlays, searchable selection, actionable feedback, measurement meters, file
selection, and caller-owned ordering. Native selects, checkboxes, radios,
switches, segmented choices, and sliders remain field functions. Apps keep
drafts, parsing, business validation, routes, requests, and persistence.

Segmented values use radio behavior and never own panels. Tab panels stay with
Da.Tabs. Searchable selection remains distinct from the select-only dropdown.
Overlay lifecycle is opt-in and documented in [workspace-components.md](workspace-components.md).

Deferred: calendar/date pickers, rich tables, toast timing, and full application
shells. A basic information table can use ordinary semantic HTML meanwhile.

## Verification boundary

Elm tests check emitted messages and observable markup. The standalone catalog
compiles every public component. Browser tests cover native submission, preserved
drafts, disabled/busy controls, error-link focus, tab instance isolation and focus,
disclosure keys, responsive containment, themes, text scaling, RTL, and motion.

Default color tokens are measured against WCAG AA text (4.5:1) and applicable
non-text contrast (3:1) thresholds. These checks cover selected token pairs,
not every rendered pixel or assistive technology. Manual screen-reader assessment
and app-specific composition remain necessary before claiming conformance.

## Alternatives considered

1. Raw style classes alone: simplest distribution, but every app would need to
   repeat labeling, error IDs, button types, and tab interaction code.
2. A large widget framework with component-local state: more coordination and
   ownership complexity than this core needs.
3. Elm view functions plus scoped CSS: selected because it centralizes repeatable
   structure and behavior while fitting the existing apps' rendering approach.

The root `elm.json` is a development/catalog application. The npm tarball is the
reuse mechanism. It includes Elm sources and CSS, and consumers declare Elm
dependencies themselves. No publication or app migration is part of this release.
