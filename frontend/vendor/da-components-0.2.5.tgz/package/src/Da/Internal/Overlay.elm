module Da.Internal.Overlay exposing (Config, attributes, config, dropdownTrigger, trigger)

import Da.Button as Button
import Da.Field as Field
import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E
import Json.Decode as D


type alias Config msg =
    { id : String, label : String, anchorId : String, open : Bool, onClose : msg }


config : String -> String -> String -> msg -> Config msg
config id label anchorId onClose =
    { id = id, label = label, anchorId = anchorId, open = False, onClose = onClose }


attributes : String -> Config msg -> List (Html.Attribute msg)
attributes kind settings =
    [ A.id settings.id
    , A.class ("da-overlay da-" ++ kind)
    , A.attribute "popover" "manual"
    , A.attribute "data-da-overlay" kind
    , A.attribute "data-da-open"
        (if settings.open then
            "true"

         else
            "false"
        )
    , A.attribute "data-da-anchor" settings.anchorId
    , A.attribute "aria-label" settings.label
    , E.on "da-close" (D.succeed settings.onClose)
    ]


trigger : String -> List (Html.Attribute msg) -> Config msg -> String -> msg -> Html msg
trigger kind attrs settings label onToggle =
    Button.view
        (attrs ++ triggerAttributes kind settings)
        Button.defaults
        label
        onToggle


dropdownTrigger : String -> List (Html.Attribute msg) -> Config msg -> String -> msg -> Html msg
dropdownTrigger kind attrs settings label onToggle =
    Field.present Field.Compact
        []
        (Html.div [ A.class "da-field da-field--surface da-dropdown" ]
            [ Html.button
                (attrs
                    ++ triggerAttributes kind settings
                    ++ [ A.type_ "button", A.class "da-dropdown__trigger", E.onClick onToggle ]
                )
                [ Html.span [ A.class "da-dropdown__value" ] [ Html.text label ]
                , Html.span [ A.class "da-dropdown__chevron", A.attribute "aria-hidden" "true" ] []
                ]
            ]
        )


triggerAttributes : String -> Config msg -> List (Html.Attribute msg)
triggerAttributes kind settings =
    [ A.id settings.anchorId
    , A.attribute "aria-controls" settings.id
    , A.attribute "aria-expanded"
        (if settings.open then
            "true"

         else
            "false"
        )
    ]
        ++ (if kind == "menu" then
                [ A.attribute "aria-haspopup" "menu" ]

            else
                []
           )
