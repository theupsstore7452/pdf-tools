module Da.Disclosure exposing (view)

{-| Native details/summary disclosure. The browser owns its open state and
keyboard activation; no Elm model or JavaScript adapter is needed.

@docs view

-}

import Html exposing (Html)
import Html.Attributes as A


view : List (Html.Attribute msg) -> String -> List (Html msg) -> Html msg
view attrs label children =
    Html.details (attrs ++ [ A.class "da-disclosure" ])
        [ Html.summary [ A.class "da-disclosure__trigger" ] [ Html.text label ]
        , Html.div [ A.class "da-disclosure__content" ] children
        ]
