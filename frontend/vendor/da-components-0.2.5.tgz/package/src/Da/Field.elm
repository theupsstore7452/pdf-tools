module Da.Field exposing
    ( Config, Orientation(..), Presentation(..), InputKind(..), SelectOption, config, present
    , input, textarea, select, selectContent, checkbox, switch, radioGroup, segmented, range
    )

{-| Labeled controls with linked help and error text. All input values are raw
strings; parsing and business validation belong to the application. IDs must be
unique within the document. Radio option values must be unique within a group.

@docs Config, Orientation, Presentation, InputKind, SelectOption, config, present
@docs input, textarea, select, selectContent, checkbox, switch, radioGroup, segmented, range

-}

import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E
import Json.Decode


type Orientation
    = Vertical
    | Horizontal
    | Responsive


{-| Form fields keep their panel presentation by default. Wrap one field,
dropdown, or combobox with `present` for workspace use:

  - Compact: a small panel with a visually hidden, still linked label.
  - Inline: a small panel with label and value side by side.
  - Embedded: a plain control in a caller-owned surface, with a hidden label.

Supply a visible placeholder or surrounding context for hidden labels. Help,
errors, IDs, events, and controlled drafts are retained. Do not nest presentations.

-}
type Presentation
    = Compact
    | Inline
    | Embedded


present : Presentation -> List (Html.Attribute msg) -> Html msg -> Html msg
present presentation attrs field =
    let
        name =
            case presentation of
                Compact ->
                    "compact"

                Inline ->
                    "inline"

                Embedded ->
                    "embedded"
    in
    Html.div (attrs ++ [ A.class "da-field-presentation", A.attribute "data-da-field-presentation" name ]) [ field ]


type InputKind
    = Text
    | Email
    | Password
    | Search
    | Decimal
    | Integer


type alias Config =
    { id : String
    , label : String
    , description : Maybe String
    , error : Maybe String
    , disabled : Bool
    , required : Bool
    , orientation : Orientation
    }


type alias SelectOption =
    { value : String, label : String, disabled : Bool }


config : String -> String -> Config
config id label =
    { id = id, label = label, description = Nothing, error = Nothing, disabled = False, required = False, orientation = Vertical }


orientationClass : Orientation -> String
orientationClass orientation =
    case orientation of
        Vertical ->
            "da-field--vertical"

        Horizontal ->
            "da-field--horizontal"

        Responsive ->
            "da-field--responsive"


describedBy : Config -> List (Html.Attribute msg)
describedBy settings =
    let
        ids =
            (if settings.description /= Nothing then
                [ settings.id ++ "-help" ]

             else
                []
            )
                ++ (if settings.error /= Nothing then
                        [ settings.id ++ "-error" ]

                    else
                        []
                   )
    in
    if List.isEmpty ids then
        []

    else
        [ A.attribute "aria-describedby" (String.join " " ids) ]


controlAttributes : Config -> List (Html.Attribute msg)
controlAttributes settings =
    [ A.id settings.id
    , A.disabled settings.disabled
    , A.required settings.required
    , A.attribute "aria-invalid"
        (if settings.error /= Nothing then
            "true"

         else
            "false"
        )
    ]
        ++ describedBy settings


messages : Config -> List (Html msg)
messages settings =
    (case settings.description of
        Nothing ->
            []

        Just help ->
            [ Html.p [ A.id (settings.id ++ "-help"), A.class "da-field__help" ] [ Html.text help ] ]
    )
        ++ (case settings.error of
                Nothing ->
                    []

                Just error ->
                    [ Html.p [ A.id (settings.id ++ "-error"), A.class "da-field__error" ] [ Html.text error ] ]
           )


labelContent : Config -> List (Html msg)
labelContent settings =
    [ Html.text settings.label ]
        ++ (if settings.required then
                [ Html.span [ A.class "da-field__required" ] [ Html.text " (required)" ] ]

            else
                []
           )


wrap : Config -> Html msg -> Html msg
wrap settings control =
    Html.div [ A.class ("da-field da-field--surface " ++ orientationClass settings.orientation) ]
        [ Html.label [ A.for settings.id, A.class "da-field__label" ] (labelContent settings)
        , Html.div [ A.class "da-field__content" ] (control :: messages settings)
        ]


kindAttributes : InputKind -> List (Html.Attribute msg)
kindAttributes kind =
    case kind of
        Text ->
            [ A.type_ "text" ]

        Email ->
            [ A.type_ "email" ]

        Password ->
            [ A.type_ "password" ]

        Search ->
            [ A.type_ "search" ]

        Decimal ->
            [ A.type_ "text", A.attribute "inputmode" "decimal" ]

        Integer ->
            [ A.type_ "text", A.attribute "inputmode" "numeric" ]


input : List (Html.Attribute msg) -> Config -> { value : String, onInput : String -> msg, kind : InputKind } -> Html msg
input attrs settings control =
    wrap settings
        (Html.input
            (attrs
                ++ controlAttributes settings
                ++ kindAttributes control.kind
                ++ [ A.classList [ ( "da-input", True ), ( "da-input--numeric", control.kind == Decimal || control.kind == Integer ) ]
                   , A.value control.value
                   , E.onInput control.onInput
                   ]
            )
            []
        )


textarea : List (Html.Attribute msg) -> Config -> { value : String, onInput : String -> msg } -> Html msg
textarea attrs settings control =
    wrap settings
        (Html.textarea (attrs ++ controlAttributes settings ++ [ A.class "da-textarea", A.value control.value, E.onInput control.onInput ]) [])


select : List (Html.Attribute msg) -> Config -> { value : String, onInput : String -> msg, options : List SelectOption } -> Html msg
select attrs settings control =
    selectContent attrs
        settings
        { value = control.value, onInput = control.onInput }
        (List.map (\option -> Html.option [ A.value option.value, A.selected (option.value == control.value), A.disabled option.disabled ] [ Html.text option.label ]) control.options)


{-| Native option/optgroup content for applications with grouped choices.
The field still owns the controlled value, label, validation, and input handler.
Supply only option and optgroup nodes, with explicit unique option values.
-}
selectContent : List (Html.Attribute msg) -> Config -> { value : String, onInput : String -> msg } -> List (Html msg) -> Html msg
selectContent attrs settings control options =
    wrap settings
        (Html.select (attrs ++ controlAttributes settings ++ [ A.class "da-select", A.value control.value, E.onInput control.onInput ])
            options
        )


checkControl : Bool -> List (Html.Attribute msg) -> Config -> { checked : Bool, onCheck : Bool -> msg } -> Html msg
checkControl isSwitch attrs settings control =
    Html.div [ A.class "da-field da-field--check" ]
        [ Html.input
            (attrs
                ++ controlAttributes settings
                ++ [ A.type_ "checkbox"
                   , A.class
                        (if isSwitch then
                            "da-switch"

                         else
                            "da-checkbox"
                        )
                   , A.checked control.checked
                   , E.onCheck control.onCheck
                   ]
                ++ (if isSwitch then
                        [ A.attribute "role" "switch" ]

                    else
                        []
                   )
            )
            []
        , Html.div [ A.class "da-field__content" ]
            (Html.label [ A.for settings.id, A.class "da-field__label" ] (labelContent settings) :: messages settings)
        ]


checkbox : List (Html.Attribute msg) -> Config -> { checked : Bool, onCheck : Bool -> msg } -> Html msg
checkbox =
    checkControl False


switch : List (Html.Attribute msg) -> Config -> { checked : Bool, onCheck : Bool -> msg } -> Html msg
switch =
    checkControl True


radioGroup : List (Html.Attribute msg) -> Config -> { value : String, onSelect : String -> msg, options : List SelectOption } -> Html msg
radioGroup =
    radioControl False


{-| A compact presentation of a native radio group. Selects a value; never
creates, hides, or associates content panels. Use Da.Tabs for tab panels.
-}
segmented : List (Html.Attribute msg) -> Config -> { value : String, onSelect : String -> msg, options : List SelectOption } -> Html msg
segmented =
    radioControl True


radioControl : Bool -> List (Html.Attribute msg) -> Config -> { value : String, onSelect : String -> msg, options : List SelectOption } -> Html msg
radioControl compact attrs settings control =
    Html.fieldset
        (attrs
            ++ [ A.id settings.id
               , A.class
                    (if compact then
                        "da-field da-radio-group da-segmented"

                     else
                        "da-field da-radio-group"
                    )
               , A.disabled settings.disabled
               ]
            ++ describedBy settings
        )
        (Html.legend [ A.class "da-field__label" ] (labelContent settings)
            :: [ Html.div [ A.class "da-radio-group__options" ]
                    (List.indexedMap
                        (\index option ->
                            let
                                optionId =
                                    settings.id ++ "-option-" ++ String.fromInt index
                            in
                            Html.div [ A.class "da-radio-option" ]
                                [ Html.input
                                    ([ A.id optionId
                                     , A.name settings.id
                                     , A.type_ "radio"
                                     , A.value option.value
                                     , A.checked (control.value == option.value)
                                     , A.disabled option.disabled
                                     , A.required settings.required
                                     , A.class "da-radio-input"
                                     , A.attribute "aria-invalid"
                                        (if settings.error /= Nothing then
                                            "true"

                                         else
                                            "false"
                                        )
                                     , E.onCheck (\_ -> control.onSelect option.value)
                                     ]
                                        ++ describedBy settings
                                    )
                                    []
                                , Html.label [ A.for optionId ] [ Html.text option.label ]
                                ]
                        )
                        control.options
                    )
               ]
            ++ messages settings
        )


{-| A native slider for a bounded numeric value. Supply finite minimum,
maximum (greater than minimum), and positive step values. The app owns units,
rounding, and validation. valueText describes the value with its units.
-}
range : List (Html.Attribute msg) -> Config -> { value : Float, minimum : Float, maximum : Float, step : Float, valueText : String, onInput : Float -> msg } -> Html msg
range attrs settings control =
    wrap settings
        (Html.div [ A.class "da-range" ]
            [ Html.input
                (attrs
                    ++ controlAttributes settings
                    ++ [ A.type_ "range"
                       , A.class "da-range__input"
                       , A.min (String.fromFloat control.minimum)
                       , A.max (String.fromFloat control.maximum)
                       , A.step (String.fromFloat control.step)
                       , A.value (String.fromFloat (clamp control.minimum control.maximum control.value))
                       , A.attribute "aria-valuetext" control.valueText
                       , E.on "input" (Json.Decode.at [ "target", "value" ] Json.Decode.string |> Json.Decode.andThen (\raw -> String.toFloat raw |> Maybe.map (control.onInput >> Json.Decode.succeed) |> Maybe.withDefault (Json.Decode.fail "Invalid slider value")))
                       ]
                )
                []
            , Html.span [ A.class "da-range__value", A.attribute "aria-hidden" "true" ] [ Html.text control.valueText ]
            ]
        )
