module Da.Tabs exposing (Tab, Config, view, focus)

{-| Controlled horizontal tabs with roving tabindex and Arrow/Home/End keys.
Use focus after handling onSelect; the catalog demonstrates the complete update.
All panels remain mounted to preserve browser state. IDs must be document-unique.
Tab IDs must be unique within the group. Disabled tabs are skipped.

@docs Tab, Config, view, focus

-}

import Browser.Dom
import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E
import Html.Keyed
import Json.Decode as D
import Task


type alias Tab msg =
    { id : String, label : String, disabled : Bool, content : Html msg }


type alias Config msg =
    { id : String, label : String, selected : String, onSelect : String -> msg, tabs : List (Tab msg) }


tabId : String -> String -> String
tabId group item =
    group ++ "-tab-" ++ item


panelId : String -> String -> String
panelId group item =
    group ++ "-panel-" ++ item


keyDecoder : Config msg -> String -> D.Decoder ( msg, Bool )
keyDecoder config current =
    let
        enabled =
            List.filter (not << .disabled) config.tabs

        ids =
            List.map .id enabled

        index =
            List.indexedMap Tuple.pair ids |> List.filter (\( _, item ) -> item == current) |> List.head |> Maybe.map Tuple.first |> Maybe.withDefault 0

        at n =
            List.drop (modBy (max 1 (List.length ids)) n) ids |> List.head
    in
    D.field "key" D.string
        |> D.andThen
            (\key ->
                let
                    target =
                        case key of
                            "ArrowRight" ->
                                at (index + 1)

                            "ArrowLeft" ->
                                at (index - 1)

                            "Home" ->
                                List.head ids

                            "End" ->
                                List.reverse ids |> List.head

                            _ ->
                                Nothing
                in
                case target of
                    Just item ->
                        D.succeed ( config.onSelect item, True )

                    Nothing ->
                        D.fail "Not a tab navigation key"
            )


view : List (Html.Attribute msg) -> Config msg -> Html msg
view attrs config =
    let
        enabled =
            List.filter (not << .disabled) config.tabs

        active =
            enabled
                |> List.filter (\tab -> tab.id == config.selected)
                |> List.head
                |> Maybe.map .id
                |> Maybe.withDefault (List.head enabled |> Maybe.map .id |> Maybe.withDefault "")
    in
    Html.div (attrs ++ [ A.class "da-tabs" ])
        [ Html.Keyed.node "div"
            [ A.class "da-tabs__list", A.attribute "role" "tablist", A.attribute "aria-label" config.label ]
            (List.map
                (\tab ->
                    ( tab.id
                    , Html.button
                        [ A.id (tabId config.id tab.id)
                        , A.type_ "button"
                        , A.class "da-tabs__tab"
                        , A.attribute "role" "tab"
                        , A.attribute "aria-controls" (panelId config.id tab.id)
                        , A.attribute "aria-selected"
                            (if active == tab.id then
                                "true"

                             else
                                "false"
                            )
                        , A.tabindex
                            (if active == tab.id then
                                0

                             else
                                -1
                            )
                        , A.disabled tab.disabled
                        , E.onClick (config.onSelect tab.id)
                        , E.preventDefaultOn "keydown" (keyDecoder config tab.id)
                        ]
                        [ Html.text tab.label ]
                    )
                )
                config.tabs
            )
        , Html.Keyed.node "div"
            []
            (List.map
                (\tab ->
                    ( tab.id
                    , Html.div
                        [ A.id (panelId config.id tab.id)
                        , A.class "da-tabs__panel"
                        , A.attribute "role" "tabpanel"
                        , A.attribute "aria-labelledby" (tabId config.id tab.id)
                        , A.hidden (active /= tab.id)
                        , A.tabindex 0
                        ]
                        [ tab.content ]
                    )
                )
                config.tabs
            )
        ]


{-| Call after updating selected. Supply your NoOp or error handler. This uses
Elm's standard Browser.Dom API; it does not install a global browser listener.
-}
focus : String -> String -> (Result Browser.Dom.Error () -> msg) -> Cmd msg
focus group selected onResult =
    Browser.Dom.focus (tabId group selected) |> Task.attempt onResult
