module Da.Feedback exposing (Tone(..), notice, noticeWithActions, status, statusWithActions, progress, meter, empty)

{-| Inline feedback. Use notice for persistent information and status for new
operation feedback. Only urgent errors use an assertive alert. None move focus.

@docs Tone, notice, noticeWithActions, status, statusWithActions, progress, meter, empty

-}

import Html exposing (Html)
import Html.Attributes as A


type Tone
    = Neutral
    | Success
    | Error
    | Warning


toneClass : Tone -> String
toneClass tone =
    case tone of
        Neutral ->
            "da-notice--neutral"

        Success ->
            "da-notice--success"

        Error ->
            "da-notice--error"

        Warning ->
            "da-notice--warning"


notice : List (Html.Attribute msg) -> Tone -> { title : String, message : String } -> Html msg
notice attrs tone config =
    noticeWithActions attrs tone { title = config.title, message = config.message, actions = [] }


noticeWithActions : List (Html.Attribute msg) -> Tone -> { title : String, message : String, actions : List (Html msg) } -> Html msg
noticeWithActions attrs tone config =
    Html.div (attrs ++ [ A.class ("da-notice " ++ toneClass tone) ])
        [ Html.p [ A.class "da-notice__title" ] [ Html.text config.title ]
        , Html.p [] [ Html.text config.message ]
        , if List.isEmpty config.actions then
            Html.text ""

          else
            Html.div [ A.class "da-notice__actions" ] config.actions
        ]


status : List (Html.Attribute msg) -> Tone -> { title : String, message : String } -> Html msg
status attrs tone config =
    statusWithActions attrs tone { title = config.title, message = config.message, actions = [] }


statusWithActions : List (Html.Attribute msg) -> Tone -> { title : String, message : String, actions : List (Html msg) } -> Html msg
statusWithActions attrs tone config =
    noticeWithActions
        (attrs
            ++ [ A.attribute "role"
                    (if tone == Error then
                        "alert"

                     else
                        "status"
                    )
               , A.attribute "aria-atomic" "true"
               ]
        )
        tone
        config


{-| A measurement such as quota usage, distinct from progress toward finishing
a task. Values are clamped. Supply finite bounds with maximum > minimum and
valueText containing the meaningful units. No percentage or quota policy is
inferred by the library.
-}
meter : List (Html.Attribute msg) -> { label : String, value : Float, minimum : Float, maximum : Float, valueText : String } -> Html msg
meter attrs config =
    let
        value =
            clamp config.minimum config.maximum config.value

        fraction =
            if config.maximum > config.minimum then
                (value - config.minimum) / (config.maximum - config.minimum)

            else
                0
    in
    Html.div (attrs ++ [ A.class "da-meter" ])
        [ Html.div [ A.class "da-meter__heading" ] [ Html.span [] [ Html.text config.label ], Html.span [] [ Html.text config.valueText ] ]
        , Html.node "meter" [ A.class "da-meter__native", A.attribute "aria-label" config.label, A.min (String.fromFloat config.minimum), A.max (String.fromFloat config.maximum), A.value (String.fromFloat value), A.attribute "aria-valuetext" config.valueText ] []
        , Html.div [ A.class "da-meter__track", A.attribute "aria-hidden" "true" ] [ Html.span [ A.style "width" (String.fromFloat (clamp 0 1 fraction * 100) ++ "%") ] [] ]
        ]


{-| Nothing is indeterminate progress. Values are clamped to 0–100.
-}
progress : List (Html.Attribute msg) -> { label : String, value : Maybe Int } -> Html msg
progress attrs config =
    let
        value =
            Maybe.map (clamp 0 100) config.value
    in
    Html.div [ A.class "da-progress" ]
        [ Html.span [] [ Html.text config.label ]
        , Html.div [ A.class "da-progress__bar" ]
            [ Html.progress
                (attrs
                    ++ [ A.class "da-progress__native", A.attribute "aria-label" config.label, A.max "100" ]
                    ++ (case value of
                            Nothing ->
                                []

                            Just percentage ->
                                [ A.value (String.fromInt percentage) ]
                       )
                )
                []
            , Html.div [ A.class "da-progress__track", A.attribute "aria-hidden" "true" ]
                [ Html.span
                    (case value of
                        Nothing ->
                            [ A.class "da-progress__fill da-progress__fill--indeterminate" ]

                        Just percentage ->
                            [ A.class "da-progress__fill"
                            , A.style "transform" ("scaleX(" ++ String.fromFloat (toFloat percentage / 100) ++ ")")
                            ]
                    )
                    []
                ]
            ]
        ]


empty : List (Html.Attribute msg) -> { title : String, description : String, actions : List (Html msg) } -> Html msg
empty attrs config =
    Html.div (attrs ++ [ A.class "da-empty" ])
        [ Html.p [ A.class "da-empty__title" ] [ Html.text config.title ]
        , Html.p [] [ Html.text config.description ]
        , Html.div [ A.class "da-row" ] config.actions
        ]
