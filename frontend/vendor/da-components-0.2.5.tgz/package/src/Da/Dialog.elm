module Da.Dialog exposing (Config, config, view)

{-| Controlled native modal dialogs. Install browser/da-components.js on the
themed root for showModal, initial focus, cancellation, and focus restoration.
Keep the dialog mounted and handle onClose by updating open. No app ports,
network calls, or global model are installed by the library.

@docs Config, config, view

-}

import Da.Button as Button
import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E
import Json.Decode as D


type alias Config msg =
    { id : String
    , title : String
    , open : Bool
    , onClose : msg
    , closeLabel : String
    , dismissible : Bool
    , initialFocus : Maybe String
    }


config : String -> String -> msg -> Config msg
config id title onClose =
    { id = id, title = title, open = False, onClose = onClose, closeLabel = "Close dialog", dismissible = True, initialFocus = Nothing }


view : List (Html.Attribute msg) -> Config msg -> { body : List (Html msg), actions : List (Html msg) } -> Html msg
view attrs settings content =
    Html.node "dialog"
        (attrs
            ++ [ A.id settings.id
               , A.class "da-overlay da-dialog"
               , A.attribute "data-da-overlay" "dialog"
               , A.attribute "data-da-open"
                    (if settings.open then
                        "true"

                     else
                        "false"
                    )
               , A.attribute "data-da-dismissible"
                    (if settings.dismissible then
                        "true"

                     else
                        "false"
                    )
               , A.attribute "data-da-initial-focus" (Maybe.withDefault "" settings.initialFocus)
               , A.attribute "aria-labelledby" (settings.id ++ "-title")
               , E.on "da-close" (D.succeed settings.onClose)
               ]
        )
        [ Html.header [ A.class "da-dialog__header" ]
            [ Html.h2 [ A.id (settings.id ++ "-title"), A.tabindex -1 ] [ Html.text settings.title ]
            , if settings.dismissible then
                Button.icon [] Button.quiet settings.closeLabel (Html.text "×") settings.onClose

              else
                Html.text ""
            ]
        , Html.div [ A.class "da-dialog__body" ] content.body
        , if List.isEmpty content.actions then
            Html.text ""

          else
            Html.footer [ A.class "da-dialog__actions" ] content.actions
        ]
