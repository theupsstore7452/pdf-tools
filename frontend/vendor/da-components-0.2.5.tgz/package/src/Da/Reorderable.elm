module Da.Reorderable exposing (Item, State, Change, Control, initial, apply, view, viewWithActions, focus)

{-| Ordered items with native pointer dragging, visible move buttons, and
Alt+ArrowUp/Down on a focused row. The app owns the items and must apply the
emitted ID order using apply, retain State, and call focus after a move. Touch users use
the buttons. No domain-specific file or page behavior is included.

@docs Item, State, Change, Control, initial, apply, view, viewWithActions, focus

-}

import Browser.Dom
import Da.Button as Button
import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E
import Html.Keyed
import Json.Decode as D
import Task


type alias Item msg =
    { id : String, label : String, content : Html msg }


type State
    = State { dragged : Maybe String, announcement : String }


type Change
    = Drag (Maybe String)
    | Move (List String) String String


type alias Control msg =
    { items : List (Item msg), state : State, disabled : Bool, onChange : Change -> msg }


initial : State
initial =
    State { dragged = Nothing, announcement = "" }


{-| Apply interaction changes to current state. Drag-end events never overwrite
an order or announcement committed by a preceding drop event. Apply order when
it is Just; Nothing preserves current items.
-}
apply : Change -> State -> { state : State, order : Maybe (List String) }
apply change (State state) =
    case change of
        Drag source ->
            { state = State { state | dragged = source }, order = Nothing }

        Move order _ announcement ->
            { state = State { dragged = Nothing, announcement = announcement }, order = Just order }


{-| Supply document-unique group IDs and unique item IDs within each group.
Translate control labels for your application.
-}
view : List (Html.Attribute msg) -> { id : String, label : String, moveUp : String, moveDown : String } -> Control msg -> Html msg
view attrs settings control =
    viewWithActions attrs settings (\_ -> []) control


{-| Append caller-owned row actions after the move buttons, preserving the same
ordering, keyboard, and focus contract as view.
-}
viewWithActions : List (Html.Attribute msg) -> { id : String, label : String, moveUp : String, moveDown : String } -> (Item msg -> List (Html msg)) -> Control msg -> Html msg
viewWithActions attrs settings actions control =
    let
        (State state) =
            control.state

        ids =
            List.map .id control.items

        place source destination =
            let
                without =
                    List.filter ((/=) source) ids

                at =
                    clamp 0 (List.length without) destination

                order =
                    List.take at without ++ [ source ] ++ List.drop at without

                name =
                    control.items |> List.filter (\item -> item.id == source) |> List.head |> Maybe.map .label |> Maybe.withDefault source
            in
            control.onChange (Move order source (name ++ ": " ++ String.fromInt (at + 1) ++ " / " ++ String.fromInt (List.length ids)))

        move index item direction =
            place item.id (index + direction)

        drag source =
            control.onChange (Drag (Just source))

        row index item =
            let
                keyboard =
                    D.map3 (\key alt target -> ( key, alt, target )) (D.field "key" D.string) (D.field "altKey" D.bool) (D.at [ "target", "id" ] D.string)
                        |> D.andThen
                            (\( key, alt, target ) ->
                                if not control.disabled && target == settings.id ++ "-item-" ++ item.id && alt && key == "ArrowUp" && index > 0 then
                                    D.succeed ( move index item -1, True )

                                else if not control.disabled && target == settings.id ++ "-item-" ++ item.id && alt && key == "ArrowDown" && index < List.length ids - 1 then
                                    D.succeed ( move index item 1, True )

                                else
                                    D.fail "Not a row move"
                            )

                dragAttrs =
                    if control.disabled then
                        []

                    else
                        [ E.on "dragstart" (D.succeed (drag item.id))
                        , E.on "dragend" (D.succeed (control.onChange (Drag Nothing)))
                        , E.preventDefaultOn "dragover"
                            (case state.dragged of
                                Just source ->
                                    if List.member source ids then
                                        D.succeed ( drag source, True )

                                    else
                                        D.fail "Stale drag"

                                Nothing ->
                                    D.fail "External drag"
                            )
                        , E.custom "drop"
                            (case state.dragged of
                                Just source ->
                                    if source /= item.id && List.member source ids then
                                        let
                                            without =
                                                List.filter ((/=) source) ids

                                            destination =
                                                without |> List.indexedMap Tuple.pair |> List.filter (\( _, id ) -> id == item.id) |> List.head |> Maybe.map Tuple.first |> Maybe.withDefault index
                                        in
                                        D.succeed { message = place source destination, stopPropagation = True, preventDefault = True }

                                    else
                                        D.succeed { message = control.onChange (Drag Nothing), stopPropagation = True, preventDefault = True }

                                Nothing ->
                                    D.fail "External drag"
                            )
                        ]

                up =
                    Button.quiet
            in
            ( item.id
            , Html.li
                ([ A.id (settings.id ++ "-item-" ++ item.id)
                 , A.class "da-reorderable__item"
                 , A.tabindex 0
                 , A.draggable
                    (if control.disabled then
                        "false"

                     else
                        "true"
                    )
                 , A.attribute "aria-describedby" (settings.id ++ "-help")
                 , E.custom "keydown" (D.map (\( message, prevent ) -> { message = message, stopPropagation = True, preventDefault = prevent }) keyboard)
                 ]
                    ++ dragAttrs
                )
                [ Html.span [ A.class "da-reorderable__position", A.attribute "aria-hidden" "true" ] [ Html.text (String.fromInt (index + 1)) ]
                , Html.div [ A.class "da-reorderable__content" ] [ item.content ]
                , Html.div [ A.class "da-reorderable__actions" ]
                    ([ Button.icon [] { up | disabled = control.disabled || index == 0 } (settings.moveUp ++ ": " ++ item.label) (Html.text "↑") (move index item -1)
                     , Button.icon [] { up | disabled = control.disabled || index == List.length ids - 1 } (settings.moveDown ++ ": " ++ item.label) (Html.text "↓") (move index item 1)
                     ]
                        ++ actions item
                    )
                ]
            )
    in
    Html.div (attrs ++ [ A.id settings.id, A.class "da-reorderable", A.attribute "role" "group", A.attribute "aria-label" settings.label ])
        [ Html.p [ A.id (settings.id ++ "-help"), A.class "da-field__help" ] [ Html.text (settings.moveUp ++ " / " ++ settings.moveDown ++ " · Alt + ↑ / ↓") ]
        , Html.Keyed.node "ol" [ A.class "da-reorderable__list" ] (List.indexedMap row control.items)
        , Html.p [ A.class "da-visually-hidden", A.attribute "role" "status", A.attribute "aria-atomic" "true" ] [ Html.text state.announcement ]
        ]


focus : String -> Change -> (Result Browser.Dom.Error () -> msg) -> Cmd msg
focus id change onResult =
    case change of
        Move _ item _ ->
            Browser.Dom.focus (id ++ "-item-" ++ item) |> Task.attempt onResult

        Drag _ ->
            Cmd.none
