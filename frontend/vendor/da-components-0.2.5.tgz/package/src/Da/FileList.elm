module Da.FileList exposing (Item, Control, view)

{-| Compact ordered file rows with a filename, optional detail, move buttons,
and removal. The app owns files, validation, removal, and processing. Ordering
uses Da.Reorderable's state, apply, and focus contract.

@docs Item, Control, view

-}

import Da.Button as Button
import Da.Reorderable as Reorderable
import Html exposing (Html)
import Html.Attributes as A


type alias Item =
    { id : String, name : String, detail : Maybe String }


type alias Control msg =
    { items : List Item
    , state : Reorderable.State
    , disabled : Bool
    , onChange : Reorderable.Change -> msg
    , onRemove : String -> msg
    }


{-| Use stable unique item IDs and a document-unique list ID. The label names
the list; moveUp, moveDown, and remove name its actions. Long names truncate
visually while retaining their full text and native title.
-}
view : List (Html.Attribute msg) -> { id : String, label : String, moveUp : String, moveDown : String, remove : String } -> Control msg -> Html msg
view attrs settings control =
    let
        danger =
            Button.danger

        itemView item =
            { id = item.id
            , label = item.name
            , content =
                Html.div [ A.class "da-file-list__meta" ]
                    [ Html.span [ A.class "da-file-list__name", A.title item.name ] [ Html.text item.name ]
                    , item.detail
                        |> Maybe.map (\detail -> Html.small [ A.class "da-file-list__detail" ] [ Html.text detail ])
                        |> Maybe.withDefault (Html.text "")
                    ]
            }

        actions item =
            [ Button.icon [] { danger | disabled = control.disabled } (settings.remove ++ ": " ++ item.label) (Html.text "×") (control.onRemove item.id) ]
    in
    Html.div (attrs ++ [ A.class "da-file-list" ])
        [ Reorderable.viewWithActions []
            { id = settings.id, label = settings.label, moveUp = settings.moveUp, moveDown = settings.moveDown }
            actions
            { items = List.map itemView control.items, state = control.state, disabled = control.disabled, onChange = control.onChange }
        ]
