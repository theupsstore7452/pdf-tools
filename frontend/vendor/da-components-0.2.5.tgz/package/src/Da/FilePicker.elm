module Da.FilePicker exposing (State, Change, Control, initial, view)

{-| Native file selection and a drop area. The app owns file validation, file
storage, reading, and uploads. accept and multiple guide the native chooser;
validate dropped file types/counts in the app as well. files=Nothing is only a
drag-state change; files=Just values is a new selection. Keep State per instance.

@docs State, Change, Control, initial, view

-}

import Da.Field as Field
import File exposing (File)
import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E
import Json.Decode as D


type State
    = State Int


type alias Change =
    { state : State, files : Maybe (List File) }


type alias Control msg =
    { state : State, accept : List String, multiple : Bool, onChange : Change -> msg }


initial : State
initial =
    State 0


fileList : D.Decoder (List File)
fileList =
    D.field "length" D.int
        |> D.andThen
            (\count ->
                List.range 0 (count - 1) |> List.foldr (\index rest -> D.map2 (::) (D.index index File.decoder) rest) (D.succeed [])
            )


fileDrag : D.Decoder ()
fileDrag =
    D.at [ "dataTransfer", "types" ] (D.list D.string)
        |> D.andThen
            (\types ->
                if List.member "Files" types then
                    D.succeed ()

                else
                    D.fail "Not a file drag"
            )


dragEvent : String -> D.Decoder ( msg, Bool ) -> Html.Attribute msg
dragEvent event decoder =
    E.custom event (D.map (\( message, prevent ) -> { message = message, stopPropagation = True, preventDefault = prevent }) decoder)


view : List (Html.Attribute msg) -> Field.Config -> Control msg -> Html msg
view attrs settings control =
    let
        (State depth) =
            control.state

        change count =
            control.onChange { state = State (max 0 count), files = Nothing }

        selected files =
            control.onChange { state = initial, files = Just files }

        described =
            [ if settings.description /= Nothing then
                Just (settings.id ++ "-help")

              else
                Nothing
            , if settings.error /= Nothing then
                Just (settings.id ++ "-error")

              else
                Nothing
            ]
                |> List.filterMap identity
                |> String.join " "

        dragAttributes =
            if settings.disabled then
                [ dragEvent "dragover" (D.map (\_ -> ( change 0, True )) fileDrag)
                , E.custom "drop" (D.map (\_ -> { message = change 0, stopPropagation = True, preventDefault = True }) fileDrag)
                ]

            else
                [ dragEvent "dragenter" (D.map (\_ -> ( change (depth + 1), True )) fileDrag)
                , dragEvent "dragleave" (D.map (\_ -> ( change (depth - 1), True )) fileDrag)
                , dragEvent "dragover" (D.map (\_ -> ( change depth, True )) fileDrag)
                , E.custom "drop" (D.at [ "dataTransfer", "files" ] fileList |> D.map (\files -> { message = selected files, stopPropagation = True, preventDefault = True }))
                ]
    in
    Html.div
        (attrs
            ++ [ A.class "da-file-picker"
               , A.attribute "data-da-dragging"
                    (if depth > 0 && not settings.disabled then
                        "true"

                     else
                        "false"
                    )
               , A.attribute "aria-disabled"
                    (if settings.disabled then
                        "true"

                     else
                        "false"
                    )
               ]
            ++ dragAttributes
        )
        [ Html.label [ A.for settings.id, A.class "da-field__label" ]
            [ Html.text
                (settings.label
                    ++ (if settings.required then
                            " (required)"

                        else
                            ""
                       )
                )
            ]
        , Html.input
            ([ A.id settings.id
             , A.class "da-file-picker__input"
             , A.type_ "file"
             , A.value ""
             , A.disabled settings.disabled
             , A.required settings.required
             , A.accept (String.join "," control.accept)
             , A.multiple control.multiple
             , A.attribute "aria-invalid"
                (if settings.error /= Nothing then
                    "true"

                 else
                    "false"
                )
             ]
                ++ (if described /= "" then
                        [ A.attribute "aria-describedby" described ]

                    else
                        []
                   )
                ++ (if settings.disabled then
                        []

                    else
                        [ E.on "change" (D.at [ "target", "files" ] fileList |> D.map selected) ]
                   )
            )
            []
        , settings.description |> Maybe.map (\help -> Html.p [ A.id (settings.id ++ "-help"), A.class "da-field__help" ] [ Html.text help ]) |> Maybe.withDefault (Html.text "")
        , settings.error |> Maybe.map (\error -> Html.p [ A.id (settings.id ++ "-error"), A.class "da-field__error" ] [ Html.text error ]) |> Maybe.withDefault (Html.text "")
        ]
