module Da.Card exposing (Heading(..), view, header, title, description, content, footer)

{-| Compose a card from optional header, body, and footer parts. Choose a title
heading appropriate for the surrounding document; a card is not clickable.

@docs Heading, view, header, title, description, content, footer

-}

import Html exposing (Html)
import Html.Attributes as A


type Heading
    = H2
    | H3
    | H4


view : List (Html.Attribute msg) -> List (Html msg) -> Html msg
view attrs children =
    Html.div (attrs ++ [ A.class "da-card" ]) children


header : List (Html.Attribute msg) -> List (Html msg) -> Html msg
header attrs children =
    Html.div (attrs ++ [ A.class "da-card__header" ]) children


title : Heading -> String -> Html msg
title heading label =
    Html.node
        (case heading of
            H2 ->
                "h2"

            H3 ->
                "h3"

            H4 ->
                "h4"
        )
        [ A.class "da-card__title" ]
        [ Html.text label ]


description : String -> Html msg
description label =
    Html.p [ A.class "da-card__description" ] [ Html.text label ]


content : List (Html.Attribute msg) -> List (Html msg) -> Html msg
content attrs children =
    Html.div (attrs ++ [ A.class "da-card__content" ]) children


footer : List (Html.Attribute msg) -> List (Html msg) -> Html msg
footer attrs children =
    Html.div (attrs ++ [ A.class "da-card__footer" ]) children
