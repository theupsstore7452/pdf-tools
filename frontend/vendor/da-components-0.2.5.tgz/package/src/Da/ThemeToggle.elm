module Da.ThemeToggle exposing (Config, view)

{-| A compact icon button for scoped light, dark, and system themes.
The application owns the selected mode and any persistence.

@docs Config, view

-}

import Da.Theme as Theme
import Html exposing (Html)
import Html.Attributes as A
import Html.Events as E


{-| Supply an accessible label in your app's language, ideally including the
current mode and the next action, such as "Dark theme. Switch to system theme".
-}
type alias Config msg =
    { mode : Theme.Mode
    , label : String
    , onChange : Theme.Mode -> msg
    }


{-| Shows the current mode as a sun, moon, or monitor. Activation requests the
next mode: Light → Dark → System → Light. Handle that message and pass the new
mode to both this control and `Theme.root`.

This native button supports Enter and Space and never submits a containing form.
Use `Html.Attributes.disabled True` in the attributes to make it unavailable.
The component owns its class, type, mode, accessible label, title, and click handler.

-}
view : List (Html.Attribute msg) -> Config msg -> Html msg
view attrs config =
    let
        ( mode, next ) =
            case config.mode of
                Theme.Light ->
                    ( "light", Theme.Dark )

                Theme.Dark ->
                    ( "dark", Theme.System )

                Theme.System ->
                    ( "system", Theme.Light )
    in
    Html.button
        (attrs
            ++ [ A.class "da-button da-button--secondary da-theme-toggle"
               , A.type_ "button"
               , A.attribute "data-da-mode" mode
               , A.attribute "aria-label" config.label
               , A.title config.label
               , E.onClick (config.onChange next)
               ]
        )
        [ Html.span [ A.class "da-theme-toggle__icon", A.attribute "aria-hidden" "true" ] [] ]
